// lab7_2

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main (int argc, char **argv){
    //  lab7_2 will open a file called happenstofall.txt 
    // if no argument is entered on the command line
    // if user entered number in command line then argc should be 2
    if(argc != 2){
        printf("usage: lab7_2 bottle_number");
        exit(1);
    }
    // check if given number of bottles is valid or not valid number is between [1,100]
    if(atoi(argv[1]) < 1 || atoi(argv[1]) > 100 ){
        printf("usage: lab7_2 bottle_number");
        exit(99);
    }
    int bottleNum = atoi(argv[1]);
    int i = 0;
    char * currentLine = NULL;
    size_t lineLenthg = 0;
    ssize_t readFlag;
    // open bottlesofbeer file
    FILE * happenstofallFile;
    happenstofallFile = fopen("happenstofall.txt", "r");
    if (happenstofallFile == NULL){
        printf("Can not open happenstofall.txt for reading");
        exit(1);
    }
    int count= 0;
    // it will print each line of text
    // from bottlesofbeer.txt all on the same line of output
        
    while ((readFlag = getline(&currentLine, &lineLenthg, happenstofallFile)) != -1) {
        // remove \n ( new line from reading line)
        strtok(currentLine, "\n");
        // if this is the first line to be printed then do not add , before it
        // but if this is not first line then add , before it
        if(count == 0){
            printf("%s",currentLine);
            count += 1;
        }
        else{
            printf(", %s",i, currentLine);
        }
    }
    // end of reading file
    // lab7_2 should now close the file happenstofall.txt
    // close file 
    fclose(happenstofallFile);
    // free memory of char* 
    if (currentLine)
        free(currentLine);
    // - at this point lab7_2 should fork a new process
    // - it then will do a corresponding exec to call lab7_3 
    // pass the present beer bottle number to it
    // add your code here to fork lab7_3
    // lab7_2 will wait until lab7_3 is complete
    
    // add your code here to wait until lab7_3 is complete
    
    // lab7_3 terminate
    // because lab7_2 was waiting for lab7_3 to terminate, lab7_2 will now terminate,
    // passing control back to lab7_1
    exit(0);
}
