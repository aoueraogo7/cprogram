// lab7_1

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main (int argc, char **argv){
    // if no argument is entered on the command line
    // if user entered number in command line then argc should be 2
    if(argc != 2){
        printf("usage: lab7_1 a_number_between_1_and_100");
        exit(1);
    }
    // check if given number of bottles is valid or not valid number is between [1,100]
    if(atoi(argv[1]) < 1 || atoi(argv[1]) > 100 ){
        printf("usage: lab7_1 a_number_between_1_and_100");
        exit(99);
    }
    int numBeerBottles = atoi(argv[1]);
    int i = 0;
    char * currentLine = NULL;
    size_t lineLenthg = 0;
    ssize_t readFlag;
    // open bottlesofbeer file
    FILE * bottlesofbeerFile;
    bottlesofbeerFile = fopen("bottlesofbeer.txt", "r");
    if (bottlesofbeerFile == NULL){
        printf("Can not open bottlesofbeer.txt for reading");
        exit(1);
    }
    int count= 0;
    for(i = numBeerBottles; i > 0 ; i--){
        // it will print the beer bottle number, followed by each line of text
        // from bottlesofbeer.txt all on the same line of output
        
        while ((readFlag = getline(&currentLine, &lineLenthg, bottlesofbeerFile)) != -1) {
            // remove \n ( new line from reading line)
            strtok(currentLine, "\n");
            // if this is the first line to be printed then do not add , before it
            // but if this is not first line then add , before it
            if(count == 0){
                printf("%d %s",i, currentLine);
                count += 1;
            }
            else{
                printf(", %d %s",i, currentLine);
            }
        }
        printf("%d i  ",i);
        // end of reading file
        // - at this point lab7_1 should fork a new process
        // it then will do a corresponding exec to call lab7_2
        // add your code here to fork lab7_2
        // lab7_1 will wait until lab7_2 is complete
        // add your code here to wait
        
        // - lab7_1 will pause for 1 second
        // add your code here pause for 1 second
        
        // - lab7_1 will then continue its loop with the next beer bottle in the descending
        // it will go to update part of loop to decrement num beer
    }
    
    // Once the beer bottle number becomes 0, the loop is complete and then
    // then lab7_1 will print the last line which is a literal (not read from a file).
    printf("\nNO MORE BOTTLES OF BEER ON THE WALL");
    // - then close the file bottlesofbeer.txt
    // close file 
    fclose(bottlesofbeerFile);
    // free memory of char* 
    if (currentLine)
        free(currentLine);
    return 0;
}
    


