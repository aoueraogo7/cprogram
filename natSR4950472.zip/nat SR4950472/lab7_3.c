// lab7_3

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main (int argc, char **argv){
    //  lab7_2 will open a file called remaining.txt 
    // if no argument is entered on the command line
    // if user entered number in command line then argc should be 2
    if(argc != 2){
        printf("usage: lab7_3 bottle_number");
        exit(1);
    }
    // check if given number of bottles is valid or not valid number is between [1,100]
    if(atoi(argv[1]) < 1 || atoi(argv[1]) > 100 ){
        printf("usage: lab7_3 bottle_number");
        exit(99);
    }
    int bottleNum = atoi(argv[1]);
    //decrement the present beer bottle number
    bottleNum--;
    int i = 0;
    char * currentLine = NULL;
    size_t lineLenthg = 0;
    ssize_t readFlag;
    // open bottlesofbeer file
    FILE * remainingFile;
    remainingFile = fopen("remaining.txt", "r");
    if (remainingFile == NULL){
        printf("Can not open remainingFile.txt for reading");
        exit(1);
    }
    int count= 0;
    // print it, followed by the contents of the file remaining.txt on the same line of output
        
    while ((readFlag = getline(&currentLine, &lineLenthg, remainingFile)) != -1) {
        // remove \n ( new line from reading line)
        strtok(currentLine, "\n");
        // if this is the first line to be printed then do not add , before it
        // but if this is not first line then add , before it
        if(count == 0){
            printf("%d %s",bottleNum,currentLine);
            count += 1;
        }
        else{
            printf(", %d %s",bottleNum, currentLine);
        }
    }
    // end of reading file
    // lab7_3 should now close the file remaining.txt
    // close file 
    fclose(remainingFile);
    // free memory of char* 
    if (currentLine)
        free(currentLine);
    
    // At this point
    // - lab7_3 will now terminate
    exit(0);
}

